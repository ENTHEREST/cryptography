/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mohit
 */
public class Main {
    public static void main(String arg[]) {
    NewJFrame a=new NewJFrame();
    a.setVisible(true);
    a.setLocationRelativeTo(null);
    }
}
